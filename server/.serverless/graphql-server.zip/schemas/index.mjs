import typeDefs from "./typeDefs.mjs";
import resolvers from "./resolvers.mjs";

export { typeDefs, resolvers };
